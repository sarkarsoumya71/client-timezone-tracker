# Client Timezone Tracker Web

A web-based client timezone tracking application that helps you keep track of clients across different time zones.

## Features
- Add, edit, and delete clients
- Automatic time updates
- Dark theme interface
- Time-sorted display (earliest to latest)
- 12-hour time format
- Persistent data storage

## Deployment on Render
1. Create a new Web Service
2. Set Build Command: `pip install -r requirements.txt`
3. Set Start Command: `gunicorn app:app`
4. Add Environment Variables:
   - `PYTHON_VERSION`: 3.10.6
   - `PORT`: 10000
   - `FLASK_ENV`: production
