let timezoneMapping = {};
let currentEditId = null;

// Fetch timezones and populate select
async function fetchTimezones() {
    const response = await fetch('/api/timezones');
    timezoneMapping = await response.json();
    populateTimezoneSelects();
}

function populateTimezoneSelects() {
    const timezones = Object.keys(timezoneMapping).sort();
    const selects = [document.getElementById('timezoneSelect'), document.getElementById('editTimezone')];
    
    selects.forEach(select => {
        select.innerHTML = '';
        timezones.forEach(tz => {
            const option = document.createElement('option');
            option.value = timezoneMapping[tz];
            option.textContent = tz;
            select.appendChild(option);
        });
    });
}

// Fetch and display clients
async function fetchClients() {
    const response = await fetch('/api/clients');
    const clients = await response.json();
    updateClientTable(clients);
}

function formatTime(timezone) {
    const options = {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    };
    return new Date().toLocaleTimeString('en-US', { ...options, timeZone: timezone });
}

function formatDate(timezone) {
    const options = {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        weekday: 'long'
    };
    return new Date().toLocaleString('en-US', { ...options, timeZone: timezone });
}

function updateClientTable(clients) {
    const tbody = document.querySelector('#clientTable tbody');
    tbody.innerHTML = '';
    
    // Sort clients by their current time
    clients.sort((a, b) => {
        const timeA = new Date().toLocaleString('en-US', { timeZone: a.timezone });
        const timeB = new Date().toLocaleString('en-US', { timeZone: b.timezone });
        return new Date(timeA) - new Date(timeB);
    });
    
    clients.forEach(client => {
        const row = document.createElement('tr');
        
        const nameCell = document.createElement('td');
        nameCell.textContent = client.name;
        
        const timeCell = document.createElement('td');
        timeCell.textContent = formatTime(client.timezone);
        timeCell.dataset.timezone = client.timezone;
        
        const dateCell = document.createElement('td');
        dateCell.textContent = formatDate(client.timezone);
        dateCell.dataset.timezone = client.timezone;
        
        const actionsCell = document.createElement('td');
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'action-buttons';
        
        const editBtn = document.createElement('button');
        editBtn.className = 'btn btn-secondary';
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => showEditModal(client);
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn btn-danger';
        deleteBtn.textContent = 'Delete';
        deleteBtn.onclick = () => showDeleteModal(client);
        
        actionsDiv.appendChild(editBtn);
        actionsDiv.appendChild(deleteBtn);
        actionsCell.appendChild(actionsDiv);
        
        row.appendChild(nameCell);
        row.appendChild(timeCell);
        row.appendChild(dateCell);
        row.appendChild(actionsCell);
        
        tbody.appendChild(row);
    });
}

// Update times every minute
function updateTimes() {
    document.querySelectorAll('td[data-timezone]').forEach(cell => {
        const timezone = cell.dataset.timezone;
        if (cell.cellIndex === 1) { // Time column
            cell.textContent = formatTime(timezone);
        } else if (cell.cellIndex === 2) { // Date column
            cell.textContent = formatDate(timezone);
        }
    });
}

// Add new client
document.getElementById('addClient').addEventListener('click', async () => {
    const name = document.getElementById('clientName').value.trim();
    const timezone = document.getElementById('timezoneSelect').value;
    
    if (!name) return;
    
    const response = await fetch('/api/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, timezone })
    });
    
    if (response.ok) {
        document.getElementById('clientName').value = '';
        fetchClients();
    }
});

// Edit modal functions
function showEditModal(client) {
    currentEditId = client.id;
    const modal = document.getElementById('editModal');
    const nameInput = document.getElementById('editName');
    const timezoneSelect = document.getElementById('editTimezone');
    
    nameInput.value = client.name;
    
    // Find and select the current timezone
    const timezoneOption = Array.from(timezoneSelect.options).find(
        option => option.value === client.timezone
    );
    if (timezoneOption) {
        timezoneOption.selected = true;
    }
    
    modal.style.display = 'block';
}

document.getElementById('saveEdit').addEventListener('click', async () => {
    if (!currentEditId) return;
    
    const name = document.getElementById('editName').value.trim();
    const timezone = document.getElementById('editTimezone').value;
    
    if (!name) return;
    
    const response = await fetch(`/api/clients/${currentEditId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, timezone })
    });
    
    if (response.ok) {
        document.getElementById('editModal').style.display = 'none';
        fetchClients();
    }
});

document.getElementById('cancelEdit').addEventListener('click', () => {
    document.getElementById('editModal').style.display = 'none';
});

// Delete modal functions
function showDeleteModal(client) {
    currentEditId = client.id;
    const modal = document.getElementById('deleteModal');
    const nameSpan = document.getElementById('deleteClientName');
    nameSpan.textContent = client.name;
    modal.style.display = 'block';
}

document.getElementById('confirmDelete').addEventListener('click', async () => {
    if (!currentEditId) return;
    
    const response = await fetch(`/api/clients/${currentEditId}`, {
        method: 'DELETE'
    });
    
    if (response.ok) {
        document.getElementById('deleteModal').style.display = 'none';
        fetchClients();
    }
});

document.getElementById('cancelDelete').addEventListener('click', () => {
    document.getElementById('deleteModal').style.display = 'none';
});

// Close modals when clicking outside
window.addEventListener('click', (event) => {
    const editModal = document.getElementById('editModal');
    const deleteModal = document.getElementById('deleteModal');
    
    if (event.target === editModal) {
        editModal.style.display = 'none';
    }
    if (event.target === deleteModal) {
        deleteModal.style.display = 'none';
    }
});

// Initialize
fetchTimezones();
fetchClients();
setInterval(updateTimes, 60000); // Update times every minute
