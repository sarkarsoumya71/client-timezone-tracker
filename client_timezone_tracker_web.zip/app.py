from flask import Flask, jsonify, request, render_template, send_from_directory
from datetime import datetime
import pytz
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-key-please-change')

# Data storage
DATA_DIR = os.getenv('DATA_DIR', os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(DATA_DIR, 'clients.json')

def load_clients():
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading clients: {e}")
    return {}

def save_clients(clients):
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, 'w') as f:
            json.dump(clients, f)
    except Exception as e:
        print(f"Error saving clients: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/clients', methods=['GET'])
def get_clients():
    clients = load_clients()
    return jsonify([{'id': i, 'name': name, 'timezone': tz} 
                   for i, (name, tz) in enumerate(clients.items())])

@app.route('/api/clients', methods=['POST'])
def add_client():
    data = request.json
    if not data or 'name' not in data or 'timezone' not in data:
        return jsonify({'error': 'Invalid data'}), 400
    
    clients = load_clients()
    clients[data['name']] = data['timezone']
    save_clients(clients)
    return jsonify({'id': len(clients)-1, 'name': data['name'], 'timezone': data['timezone']})

@app.route('/api/clients/<int:client_id>', methods=['PUT'])
def update_client(client_id):
    data = request.json
    if not data or 'name' not in data or 'timezone' not in data:
        return jsonify({'error': 'Invalid data'}), 400
    
    clients = load_clients()
    try:
        # Find and remove old name
        old_name = list(clients.keys())[client_id]
        del clients[old_name]
        
        # Add updated client
        clients[data['name']] = data['timezone']
        save_clients(clients)
        return jsonify({'id': client_id, 'name': data['name'], 'timezone': data['timezone']})
    except IndexError:
        return jsonify({'error': 'Client not found'}), 404

@app.route('/api/clients/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    clients = load_clients()
    try:
        name = list(clients.keys())[client_id]
        del clients[name]
        save_clients(clients)
        return '', 204
    except IndexError:
        return jsonify({'error': 'Client not found'}), 404

@app.route('/api/timezones', methods=['GET'])
def get_timezones():
    timezone_mapping = {
        "UTC (UTC+0)": "UTC",
        "GMT (UTC+0)": "GMT",
        "EST (UTC-5)": "America/New_York",
        "EDT (UTC-4)": "America/New_York",
        "CST (UTC-6)": "America/Chicago",
        "CDT (UTC-5)": "America/Chicago",
        "MST (UTC-7)": "America/Denver",
        "MDT (UTC-6)": "America/Denver",
        "PST (UTC-8)": "America/Los_Angeles",
        "PDT (UTC-7)": "America/Los_Angeles",
        "BRT (UTC-3)": "America/Sao_Paulo",
        "ART (UTC-3)": "America/Argentina/Buenos_Aires",
        "CET (UTC+1)": "Europe/Paris",
        "CEST (UTC+2)": "Europe/Paris",
        "EET (UTC+2)": "Europe/Istanbul",
        "EEST (UTC+3)": "Europe/Istanbul",
        "WET (UTC+0)": "Europe/London",
        "WEST (UTC+1)": "Europe/London",
        "WAT (UTC+1)": "Africa/Lagos",
        "CAT (UTC+2)": "Africa/Johannesburg",
        "EAT (UTC+3)": "Africa/Nairobi",
        "IST (UTC+5:30)": "Asia/Kolkata",
        "PKT (UTC+5)": "Asia/Karachi",
        "BST (UTC+6)": "Asia/Dhaka",
        "ICT (UTC+7)": "Asia/Bangkok",
        "CST (UTC+8)": "Asia/Shanghai",
        "JST (UTC+9)": "Asia/Tokyo",
        "KST (UTC+9)": "Asia/Seoul",
        "AEST (UTC+10)": "Australia/Sydney",
        "AEDT (UTC+11)": "Australia/Sydney",
        "ACST (UTC+9:30)": "Australia/Adelaide",
        "ACDT (UTC+10:30)": "Australia/Adelaide",
        "AWST (UTC+8)": "Australia/Perth"
    }
    return jsonify(timezone_mapping)

if __name__ == '__main__':
    # Only use debug mode in development
    debug = os.getenv('FLASK_ENV') == 'development'
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=debug)
